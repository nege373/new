import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './sections/About';
import Services from './sections/Services';
import SchemaTherapy from './sections/SchemaTherapy';
import Sessions from './sections/Sessions';
import Contact from './sections/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <About />
      <Services />
      <SchemaTherapy />
      <Sessions />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;